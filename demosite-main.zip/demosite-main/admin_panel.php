<?php
session_start();
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache');
if (!isset($_SESSION['user_id'])) {
    header("Location: authorization_page.php");
    exit;
}
require 'db.php';

$sql = "SELECT 
            r.id AS request_id,
            CONCAT(u.surname, ' ', u.name, ' ', u.last_name) AS full_name,
            u.phone AS user_phone,
            r.from_address,
            r.to_address,
            r.date,
            r.delivery_type,
            r.weight,
            r.dimensions,
            r.status,
            r.created_at
        FROM cargo_requests r
        JOIN users u ON r.user_id = u.id";

$result = $conn->query($sql);
$requests = $result->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style1.css">
    <title>Администрирование</title>
    <script src="script.js"></script>
</head>

<body>
    <div id="logoutModal" style="display:none;" class="modal">
        <div class="modal-content">
            <p>Вы действительно хотите выйти?</p>
            <button onclick="logout()">Да</button>
            <button onclick="closeModal()">Нет</button>
        </div>
    </div>
    <div class="container">
        <div class="header">



            <h1 class="title">История заявок пользователей</h1>


            <form action="logout.php" class="logout-form">
                <button type="submit" class="logout-button" onclick="confirmLogout(); return false;">
                    Выйти из системы
                </button>
            </form>
        </div>

        <div class="cards-container">
            <?php foreach ($requests as $request): ?>
                <div class="card">
                    <p>Заявка №<?= htmlspecialchars($request['request_id']) ?></p>
                    <p>ФИО: <?= htmlspecialchars($request['full_name']) ?></p>
                    <p>Телефон: <?= htmlspecialchars($request['user_phone']) ?></p>
                    <p>Адрес отправления: <?= htmlspecialchars($request['from_address']) ?></p>
                    <p>Адрес доставки: <?= htmlspecialchars($request['to_address']) ?></p>
                    <p>Дата: <?= htmlspecialchars($request['date']) ?></p>
                    <p>Тип доставки: <?= htmlspecialchars($request['delivery_type']) ?></p>
                    <p>Вес: <?= htmlspecialchars($request['weight']) ?> кг</p>
                    <p>Габариты: <?= htmlspecialchars($request['dimensions']) ?> см</p>
                    <p>Статус: <?= htmlspecialchars($request['status']) ?></p>
                    <form method="POST" action="update_request.php">
                        <input type="hidden" name="request_id" value="<?= $request['request_id'] ?>">
                        <select name="status">
                            <option value="Новая" <?= $request['status'] === 'Новая' ? 'selected' : '' ?>>Новая</option>
                            <option value="В работе" <?= $request['status'] === 'В работе' ? 'selected' : '' ?>>В работе</option>
                            <option value="Отменена" <?= $request['status'] === 'Отменена' ? 'selected' : '' ?>>Отменена</option>
                        </select>
                        <input type="text" name="cancel_reason" placeholder="Причина отмены" <?= $request['status'] !== 'Отменена' ? 'style="display:none;"' : '' ?>>
                        <button type="submit">Сохранить</button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>

        <script>
            document.querySelectorAll('select[name="status"]').forEach(select => {
                select.addEventListener('change', function() {
                    const reasonInput = this.nextElementSibling;
                    if (this.value === 'Отменена') {
                        reasonInput.style.display = 'block';
                    } else {
                        reasonInput.style.display = 'none';
                    }
                });
            });

            window.onload = function() {
                if (!window.performance || performance.navigation.type === 2) {
                    location.reload(true);
                }
            };
        </script>

</body>

</html>