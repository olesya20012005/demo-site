<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style1.css">
    <link rel="stylesheet" href="style_register.css">

    <title>Создание заявки</title>
    <style>

    </style>
    <script src="script.js"></script>
</head>

<body>
    <div id="logoutModal" style="display:none;" class="modal">
        <div class="modal-content">
            <p>Вы действительно хотите выйти?</p>
            <button onclick="logout()">Да</button>
            <button onclick="closeModal()">Нет</button>
        </div>
    </div>
    <div class="container">

        <div class="header">
            <a href="cabinet.php">Вернуться в личный кабинет</a>
            <h1 class="title">Создание заявки</h1>
            <form action="logout.php" class="logout-form">
                <button type="submit" class="logout-button" onclick="confirmLogout(); return false;">
                    Выйти из системы
                </button>
            </form>
        </div>

        <form class="auth_form" method="post" action="request.php">
            <div class="form-group">
                <label for="from_address">Адрес отправления*</label>
                <input type="text" id="from_address" name="from_address" placeholder="Введите адрес отправления" required>
            </div>
            <div class="form-group">
                <label for="to_address">Адрес доставки*</label>
                <input type="text" id="to_address" name="to_address" placeholder="Введите адрес доставки" required>
            </div>
            <div class="form-group">
                <label for="phone">Телефон*</label>
                <input type="phone" id="phone" name="phone" placeholder="+7()" required>
            </div>
            <div class="form-group">
                <label for="delivery_type">Тип доставки*</label>
                <select name="delivery_type" id="delivery_type">
                    <option value="" disabled selected hidden> Выберите тип доставки</option>
                    <option
                        value="Хрупкое">Хрупкое</option>
                    <option value="Скоропортящееся">Скоропортящееся</option>
                    <option value="Рефрижератор">Рефрижератор</option>
                    <option value="Животные">Животные</option>
                    <option value="Жидкость">Жидкость</option>
                    <option value="Мебель">Мебель</option>
                    <option value="Мусор">Мусор</option>
                </select>
            </div>




            <div class="form-group">
                <label for="date">Дата и время*</label>
                <input type="datetime-local" id="date" name="date" required>
            </div>
            <div class="form-group">
                <label for="weight">Вес (кг)*</label>
                <input type="number" id="weight" name="weight" min="1" required>
            </div>

            <div class="form-group">
                <label for="dimensions">Габариты (Ш x В x Д в см)*</label>
                <input type="text" id="dimensions" name="dimensions" placeholder="Например: 50x40x30" required>
            </div>
            <div class="reg_info">* - обязательное поле</div>
            <button type="submit" class="submit-form_button">Сформировать заявку</button>
        </form>
    </div>
</body>

</html>