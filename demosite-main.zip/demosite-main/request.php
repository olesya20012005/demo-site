<?php
require 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: authorization.php");
    exit();
}

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $from_address = trim($_POST['from_address']);
    $to_address = trim($_POST['to_address']);
    $phone = trim($_POST['phone']);
    $date = $_POST['date'];
    $delivery_type = isset($_POST['delivery_type']) ? trim($_POST['delivery_type']) : '';
    $weight = floatval($_POST['weight']);
    $dimensions = trim($_POST['dimensions']);
    $user_id = $_SESSION['user_id'];

    if (!$from_address || !$to_address || !$phone || !$date || !$delivery_type || !$weight || !$dimensions) {
        die("Пожалуйста, заполните все обязательные поля.");
    }

    try {
        $stmt = $conn->prepare("INSERT INTO cargo_requests (
               user_id, from_address, to_address, phone, date,
               delivery_type, weight, dimensions, status
           ) VALUES (
               :user_id, :from_address, :to_address, :phone, :date,
               :delivery_type, :weight, :dimensions, 'Создана'
           )");

        $stmt->execute([
            ':user_id' => $user_id,
            ':from_address' => $from_address,
            ':to_address' => $to_address,
            ':phone' => $phone,
            ':date' => $date,
            ':delivery_type' => $delivery_type,
            ':weight' => $weight,
            ':dimensions' => $dimensions
        ]);

        header('Location: cabinet.php');
        exit;
    } catch (PDOException $e) {
        die("Ошибка при создании заявки: " . $e->getMessage());
    }
}
