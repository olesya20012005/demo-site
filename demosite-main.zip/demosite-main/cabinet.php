<?php
session_start();
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache');
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: authorization_page.php");
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $sql = "SELECT id, from_address, to_address, phone, date, delivery_type, weight, dimensions, status, created_at
            FROM cargo_requests
            WHERE user_id = :user_id";

    $stmt = $conn->prepare($sql);
    $stmt->execute([':user_id' => $user_id]);
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Ошибка при получении заявок: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style1.css">
    <title>Личный кабинет</title>
    <style>
        body {
            background: #E9E9E9;
        }
    </style>

    <script src="script.js"></script>
</head>

<body>
    <div id="logoutModal" style="display:none;" class="modal">
        <div class="modal-content">
            <p>Вы действительно хотите выйти?</p>
            <button onclick="logout()">Да</button>
            <button onclick="closeModal()">Нет</button>
        </div>
    </div>
    <div class="container">
        <div class="header">



            <h1 class="title">История заявок</h1>


            <form action="logout.php" class="logout-form">
                <button type="submit" class="logout-button" onclick="confirmLogout(); return false;">
                    Выйти из системы
                </button>
            </form>
        </div>

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID Заявки</th>
                        <th>Адрес отправления</th>
                        <th>Адрес доставки</th>
                        <th>Телефон</th>
                        <th>Дата</th>
                        <th>Тип доставки</th>
                        <th>Вес (кг)</th>
                        <th>Габариты (см)</th>
                        <th>Статус</th>
                        <th>Дата создания</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($requests as $request): ?>
                        <tr>
                            <td><?= htmlspecialchars($request['id']) ?></td>
                            <td><?= htmlspecialchars($request['from_address']) ?></td>
                            <td><?= htmlspecialchars($request['to_address']) ?></td>
                            <td><?= htmlspecialchars($request['phone']) ?></td>
                            <td><?= htmlspecialchars($request['date']) ?></td>
                            <td><?= htmlspecialchars($request['delivery_type']) ?></td>
                            <td><?= htmlspecialchars($request['weight']) ?></td>
                            <td><?= htmlspecialchars($request['dimensions']) ?></td>
                            <td><?= htmlspecialchars($request['status']) ?></td>
                            <td><?= htmlspecialchars($request['created_at']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="create_request">
            <form action="create_request.php">
                <button type="submit" class="submit-form_button create-request_button">Создать заявку</button>
            </form>
        </div>
    </div>

    <script>
        window.onload = function() {
            if (!window.performance || performance.navigation.type === 2) {
                location.reload(true);
            }
        };
    </script>
</body>

</html>